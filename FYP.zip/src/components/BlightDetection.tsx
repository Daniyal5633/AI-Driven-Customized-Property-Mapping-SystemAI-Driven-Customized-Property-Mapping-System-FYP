import React, { useState, useCallback, useEffect, useRef } from 'react';
import {
  Box,
  Button,
  Paper,
  Typography,
  CircularProgress,
  Grid,
  Slider,
  FormControlLabel,
  Switch,
} from '@mui/material';
import { CloudUpload } from '@mui/icons-material';
import * as tf from '@tensorflow/tfjs';

interface BlightAnalysis {
  score: number;
  areas: Array<{
    x: number;
    y: number;
    width: number;
    height: number;
    confidence: number;
  }>;
}

const createModel = async () => {
  // Create a simpler model architecture
  const model = tf.sequential();
  
  // Add a simple convolutional layer
  model.add(tf.layers.conv2d({
    inputShape: [224, 224, 3],
    kernelSize: 3,
    filters: 16,
    activation: 'relu'
  }));
  
  // Add pooling
  model.add(tf.layers.maxPooling2d({poolSize: 2, strides: 2}));
  
  // Add flatten layer
  model.add(tf.layers.flatten());
  
  // Add dense layer for output
  model.add(tf.layers.dense({units: 1, activation: 'sigmoid'}));

  // Compile the model
  model.compile({
    optimizer: tf.train.adam(0.001),
    loss: 'binaryCrossentropy',
    metrics: ['accuracy']
  });

  // Initialize the model weights with random values
  const dummyData = tf.zeros([1, 224, 224, 3]);
  const dummyLabels = tf.zeros([1, 1]);
  
  // Train for one step to initialize weights
  await model.fit(dummyData, dummyLabels, {
    epochs: 1,
    batchSize: 1
  });

  // Clean up dummy tensors
  dummyData.dispose();
  dummyLabels.dispose();

  return model;
};

const BlightDetection: React.FC = () => {
  const modelRef = useRef<tf.LayersModel | null>(null);
  const [modelReady, setModelReady] = useState(false);
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<BlightAnalysis | null>(null);
  const [threshold, setThreshold] = useState(0.5);
  const [showOverlay, setShowOverlay] = useState(true);

  useEffect(() => {
    let isSubscribed = true;

    const loadModel = async () => {
      try {
        // Create and initialize the model
        const newModel = await createModel();
        
        if (isSubscribed) {
          modelRef.current = newModel;
          setModelReady(true);
        } else {
          newModel.dispose();
        }
      } catch (error) {
        console.error('Error loading model:', error);
        setModelReady(false);
      }
    };

    loadModel();
    
    return () => {
      isSubscribed = false;
      if (modelRef.current) {
        modelRef.current.dispose();
        modelRef.current = null;
        setModelReady(false);
      }
    };
  }, []);

  const handleImageUpload = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedImage(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  }, []);

  const preprocessImage = async (imageUrl: string): Promise<tf.Tensor | null> => {
    try {
      return new Promise((resolve, reject) => {
        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.onload = () => {
          try {
            // Convert image to tensor and preprocess
            const pixels = tf.browser.fromPixels(img);
            const resized = pixels.resizeNearestNeighbor([224, 224]);
            const normalized = resized.toFloat().div(255.0);
            const batched = normalized.expandDims(0);
            
            // Clean up intermediate tensors
            pixels.dispose();
            resized.dispose();
            normalized.dispose();
            
            resolve(batched);
          } catch (error) {
            reject(error);
          }
        };
        img.onerror = reject;
        img.src = imageUrl;
      });
    } catch (error) {
      console.error('Error preprocessing image:', error);
      return null;
    }
  };

  const analyzeImage = async () => {
    if (!selectedImage || !modelRef.current || !modelReady) return;

    setLoading(true);
    let imageTensor: tf.Tensor | null = null;
    
    try {
      // Preprocess the image
      imageTensor = await preprocessImage(imagePreview);
      if (!imageTensor) throw new Error('Failed to preprocess image');

      // Make prediction
      const logits = modelRef.current.predict(imageTensor) as tf.Tensor;
      const predictionValue = logits.dataSync()[0];
      
      // Clean up tensors
      logits.dispose();

      // For demo purposes, we'll generate some random blight areas
      const areas = Array(3).fill(null).map(() => ({
        x: Math.random() * 0.8,
        y: Math.random() * 0.8,
        width: Math.random() * 0.2 + 0.1,
        height: Math.random() * 0.2 + 0.1,
        confidence: Math.random() * 0.3 + 0.7,
      }));

      setResult({
        score: predictionValue,
        areas,
      });
    } catch (error) {
      console.error('Error analyzing image:', error);
    } finally {
      // Clean up tensors
      if (imageTensor) {
        imageTensor.dispose();
      }
      setLoading(false);
    }
  };

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h5" gutterBottom>
        Building Blight Detection
      </Typography>
      <Typography variant="body1" sx={{ mb: 3 }}>
        Upload an image of a building to analyze for signs of blight using our AI model.
      </Typography>

      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Paper
            sx={{
              p: 3,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              minHeight: 400,
            }}
          >
            <input
              accept="image/*"
              style={{ display: 'none' }}
              id="blight-image-upload"
              type="file"
              onChange={handleImageUpload}
            />
            <label htmlFor="blight-image-upload">
              <Button
                component="span"
                variant="contained"
                startIcon={<CloudUpload />}
                sx={{ mb: 2 }}
              >
                Upload Image
              </Button>
            </label>

            <Box sx={{ position: 'relative', width: '100%', height: 300 }}>
              {imagePreview && (
                <>
                  <Box
                    sx={{
                      width: '100%',
                      height: '100%',
                      backgroundImage: `url(${imagePreview})`,
                      backgroundSize: 'contain',
                      backgroundPosition: 'center',
                      backgroundRepeat: 'no-repeat',
                    }}
                  />
                  {showOverlay && result && (
                    <Box
                      sx={{
                        position: 'absolute',
                        top: 0,
                        left: 0,
                        right: 0,
                        bottom: 0,
                      }}
                    >
                      {result.areas
                        .filter((area) => area.confidence >= threshold)
                        .map((area, index) => (
                          <Box
                            key={index}
                            sx={{
                              position: 'absolute',
                              left: `${area.x * 100}%`,
                              top: `${area.y * 100}%`,
                              width: `${area.width * 100}%`,
                              height: `${area.height * 100}%`,
                              border: '2px solid #ff4444',
                              backgroundColor: 'rgba(255, 68, 68, 0.2)',
                            }}
                          />
                        ))}
                    </Box>
                  )}
                </>
              )}
            </Box>

            <Button
              variant="contained"
              color="primary"
              onClick={analyzeImage}
              disabled={!selectedImage || loading || !modelReady}
              sx={{ mt: 2 }}
            >
              {loading ? <CircularProgress size={24} /> : 'Analyze Blight'}
            </Button>
          </Paper>
        </Grid>

        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3, minHeight: 400 }}>
            <Typography variant="h6" gutterBottom>
              Analysis Results
            </Typography>

            {result ? (
              <Box>
                <Typography variant="body1" sx={{ mb: 2 }}>
                  Overall Blight Score: {(result.score * 100).toFixed(1)}%
                </Typography>

                <Typography variant="body2" sx={{ mb: 2 }}>
                  Detection Threshold
                </Typography>
                <Slider
                  value={threshold}
                  onChange={(_, value) => setThreshold(value as number)}
                  min={0}
                  max={1}
                  step={0.05}
                  valueLabelDisplay="auto"
                  valueLabelFormat={(value) => `${(value * 100).toFixed(0)}%`}
                  sx={{ mb: 3 }}
                />

                <FormControlLabel
                  control={
                    <Switch
                      checked={showOverlay}
                      onChange={(e) => setShowOverlay(e.target.checked)}
                    />
                  }
                  label="Show Detection Overlay"
                />

                <Typography variant="body2" color="text.secondary" sx={{ mt: 2 }}>
                  {result.areas.filter((a) => a.confidence >= threshold).length} areas of
                  concern detected above the threshold.
                </Typography>
              </Box>
            ) : (
              <Typography color="text.secondary">
                Upload and analyze an image to see the results here.
              </Typography>
            )}
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
};

export default BlightDetection; 