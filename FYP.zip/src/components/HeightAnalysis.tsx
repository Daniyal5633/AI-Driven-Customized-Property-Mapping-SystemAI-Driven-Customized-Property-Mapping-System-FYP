import React, { useState, useCallback } from 'react';
import {
  Box,
  Button,
  Paper,
  Typography,
  CircularProgress,
  Grid,
} from '@mui/material';
import { CloudUpload } from '@mui/icons-material';

interface AnalysisResult {
  height: number;
  confidence: number;
  unit: string;
}

const HeightAnalysis: React.FC = () => {
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);

  const handleImageUpload = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedImage(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  }, []);

  const analyzeImage = async () => {
    if (!selectedImage) return;

    setLoading(true);
    try {
      // Here we'll integrate with the Python height calculation model
      // For now, we'll simulate the analysis
      const formData = new FormData();
      formData.append('image', selectedImage);

      // Simulated API call
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Mock result
      setResult({
        height: 25.5,
        confidence: 0.92,
        unit: 'meters'
      });
    } catch (error) {
      console.error('Error analyzing image:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h5" gutterBottom>
        Building Height Analysis
      </Typography>
      <Typography variant="body1" sx={{ mb: 3 }}>
        Upload an image of a building to calculate its height using our AI model.
      </Typography>

      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Paper
            sx={{
              p: 3,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              minHeight: 400,
            }}
          >
            <input
              accept="image/*"
              style={{ display: 'none' }}
              id="image-upload"
              type="file"
              onChange={handleImageUpload}
            />
            <label htmlFor="image-upload">
              <Button
                component="span"
                variant="contained"
                startIcon={<CloudUpload />}
                sx={{ mb: 2 }}
              >
                Upload Image
              </Button>
            </label>

            {imagePreview && (
              <Box
                sx={{
                  width: '100%',
                  height: 300,
                  backgroundImage: `url(${imagePreview})`,
                  backgroundSize: 'contain',
                  backgroundPosition: 'center',
                  backgroundRepeat: 'no-repeat',
                  mb: 2,
                }}
              />
            )}

            <Button
              variant="contained"
              color="primary"
              onClick={analyzeImage}
              disabled={!selectedImage || loading}
              sx={{ mt: 2 }}
            >
              {loading ? <CircularProgress size={24} /> : 'Analyze Height'}
            </Button>
          </Paper>
        </Grid>

        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3, minHeight: 400 }}>
            <Typography variant="h6" gutterBottom>
              Analysis Results
            </Typography>

            {result ? (
              <Box>
                <Typography variant="body1" sx={{ mb: 2 }}>
                  Estimated Height: {result.height} {result.unit}
                </Typography>
                <Typography variant="body1" sx={{ mb: 2 }}>
                  Confidence: {(result.confidence * 100).toFixed(1)}%
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Note: This is an AI-powered estimation. For critical applications,
                  please verify with traditional measurement methods.
                </Typography>
              </Box>
            ) : (
              <Typography color="text.secondary">
                Upload and analyze an image to see the results here.
              </Typography>
            )}
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
};

export default HeightAnalysis; 