import React from 'react';
import {
  Box,
  Paper,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Button,
} from '@mui/material';
import { Add as AddIcon } from '@mui/icons-material';

interface Property {
  id: string;
  address: string;
  city: string;
  state: string;
  price: number;
  status: 'Available' | 'Sold' | 'Pending';
}

const sampleProperties: Property[] = [
  {
    id: '1',
    address: '123 Main St',
    city: 'Miami',
    state: 'FL',
    price: 450000,
    status: 'Available',
  },
  {
    id: '2',
    address: '456 Oak Ave',
    city: 'Los Angeles',
    state: 'CA',
    price: 750000,
    status: 'Pending',
  },
  {
    id: '3',
    address: '789 Pine Rd',
    city: 'Seattle',
    state: 'WA',
    price: 550000,
    status: 'Available',
  },
];

const PropertyList: React.FC = () => {
  return (
    <Box sx={{ p: 3 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 3 }}>
        <Typography variant="h5">Properties</Typography>
        <Button
          variant="contained"
          color="primary"
          startIcon={<AddIcon />}
        >
          Add Property
        </Button>
      </Box>

      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Address</TableCell>
              <TableCell>City</TableCell>
              <TableCell>State</TableCell>
              <TableCell align="right">Price</TableCell>
              <TableCell>Status</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {sampleProperties.map((property) => (
              <TableRow
                key={property.id}
                sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
              >
                <TableCell component="th" scope="row">
                  {property.address}
                </TableCell>
                <TableCell>{property.city}</TableCell>
                <TableCell>{property.state}</TableCell>
                <TableCell align="right">
                  ${property.price.toLocaleString()}
                </TableCell>
                <TableCell>{property.status}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
};

export default PropertyList; 