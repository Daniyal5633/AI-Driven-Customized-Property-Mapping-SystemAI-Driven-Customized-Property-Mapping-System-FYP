import React, { useState } from 'react';
import {
  Box,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  TextField,
  Button,
  Typography,
  Paper,
} from '@mui/material';
import { MapContainer, TileLayer } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import { LatLngTuple } from 'leaflet';

const GeoLocation: React.FC = () => {
  const [country, setCountry] = useState('USA');
  const [state, setState] = useState('');
  const [city, setCity] = useState('');
  const [postalCode, setPostalCode] = useState('');
  const [center] = useState<LatLngTuple>([39.8283, -98.5795]);

  const states = [
    'Florida',
    'California',
    'Washington',
    'DC',
    // Add more states as needed
  ];

  const handleSearch = () => {
    // Here you would typically make an API call to get coordinates
    // For demo purposes, we'll just log the search parameters
    console.log({ country, state, city, postalCode });
  };

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h5" gutterBottom>
        Geolocation Setting
      </Typography>
      <Typography variant="body1" sx={{ mb: 3 }}>
        Select as many or as little locations as you'd like to search for. The more specific you are, the better the results.
      </Typography>

      <Paper sx={{ p: 3, mb: 3 }}>
        <Box sx={{ display: 'flex', gap: 2, mb: 2 }}>
          <FormControl fullWidth>
            <InputLabel>Country</InputLabel>
            <Select
              value={country}
              label="Country"
              onChange={(e) => setCountry(e.target.value)}
            >
              <MenuItem value="USA">USA</MenuItem>
            </Select>
          </FormControl>

          <FormControl fullWidth>
            <InputLabel>State</InputLabel>
            <Select
              value={state}
              label="State"
              onChange={(e) => setState(e.target.value)}
            >
              {states.map((s) => (
                <MenuItem key={s} value={s}>
                  {s}
                </MenuItem>
              ))}
            </Select>
          </FormControl>

          <TextField
            fullWidth
            label="City"
            value={city}
            onChange={(e) => setCity(e.target.value)}
          />

          <TextField
            fullWidth
            label="Postal Codes"
            value={postalCode}
            onChange={(e) => setPostalCode(e.target.value)}
          />

          <Button
            variant="contained"
            color="primary"
            onClick={handleSearch}
            sx={{ minWidth: 100 }}
          >
            Search
          </Button>
        </Box>
      </Paper>

      <Box sx={{ height: 500, width: '100%' }}>
        <MapContainer
          center={center}
          zoom={4}
          style={{ height: '100%', width: '100%' }}
          scrollWheelZoom={false}
        >
          <TileLayer
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          />
        </MapContainer>
      </Box>
    </Box>
  );
};

export default GeoLocation; 