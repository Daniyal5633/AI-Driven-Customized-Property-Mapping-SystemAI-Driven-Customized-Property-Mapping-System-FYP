import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import Dashboard from './components/Dashboard';
import PropertyList from './components/PropertyList';
import GeoLocation from './components/GeoLocation';
import HeightAnalysis from './components/HeightAnalysis';
import BlightDetection from './components/BlightDetection';

const theme = createTheme({
  palette: {
    primary: {
      main: '#ff7043',
    },
    secondary: {
      main: '#2196f3',
    },
    background: {
      default: '#f5f5f5',
    },
  },
});

function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Router>
        <Routes>
          <Route path="/" element={<Dashboard />}>
            <Route index element={<PropertyList />} />
            <Route path="geolocation" element={<GeoLocation />} />
            <Route path="height-analysis" element={<HeightAnalysis />} />
            <Route path="blight-detection" element={<BlightDetection />} />
          </Route>
        </Routes>
      </Router>
    </ThemeProvider>
  );
}

export default App; 