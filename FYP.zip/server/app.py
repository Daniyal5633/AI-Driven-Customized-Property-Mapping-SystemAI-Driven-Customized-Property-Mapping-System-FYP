from flask import Flask, request, jsonify
from flask_cors import CORS
import sys
import os
import numpy as np
from PIL import Image
import tensorflow as tf

# Add the height calculation model path to system path
sys.path.append('../Height Calculation Model')
from heightMeasurement import HeightMeasurement

app = Flask(__name__)
CORS(app)

# Initialize height measurement model
height_model = HeightMeasurement()

# Initialize blight detection model (placeholder)
def load_blight_model():
    # In a real application, you would load a trained model
    # For now, we'll create a simple model
    model = tf.keras.Sequential([
        tf.keras.layers.Conv2D(32, 3, activation='relu', input_shape=(224, 224, 3)),
        tf.keras.layers.MaxPooling2D(),
        tf.keras.layers.Flatten(),
        tf.keras.layers.Dense(1, activation='sigmoid')
    ])
    return model

blight_model = load_blight_model()

def preprocess_image(image):
    # Resize image to 224x224
    image = image.resize((224, 224))
    # Convert to numpy array and normalize
    img_array = np.array(image) / 255.0
    return np.expand_dims(img_array, axis=0)

@app.route('/api/analyze/height', methods=['POST'])
def analyze_height():
    if 'image' not in request.files:
        return jsonify({'error': 'No image provided'}), 400
    
    try:
        image_file = request.files['image']
        image = Image.open(image_file)
        
        # Use the existing height measurement model
        height = height_model.measure_height(image)
        
        return jsonify({
            'height': height,
            'unit': 'meters',
            'confidence': 0.92  # This should come from the model
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/analyze/blight', methods=['POST'])
def analyze_blight():
    if 'image' not in request.files:
        return jsonify({'error': 'No image provided'}), 400
    
    try:
        image_file = request.files['image']
        image = Image.open(image_file)
        
        # Preprocess image for blight detection
        processed_image = preprocess_image(image)
        
        # Get model prediction
        prediction = blight_model.predict(processed_image)
        score = float(prediction[0][0])
        
        # Generate sample blight areas (in a real application, this would come from the model)
        areas = []
        if score > 0.5:
            areas = [
                {
                    'x': 0.2,
                    'y': 0.3,
                    'width': 0.2,
                    'height': 0.15,
                    'confidence': 0.85
                },
                {
                    'x': 0.6,
                    'y': 0.4,
                    'width': 0.25,
                    'height': 0.2,
                    'confidence': 0.75
                }
            ]
        
        return jsonify({
            'score': score,
            'areas': areas
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000) 